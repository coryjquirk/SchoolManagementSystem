# SchoolManagementSystem
AD - SBA - Core Java/Hibernate/JUnit
